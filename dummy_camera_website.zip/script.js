document.getElementById("btn").onclick = async function(){
  try{
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user" }
    });
    document.getElementById("video").srcObject = stream;
  }catch(e){
    alert("Camera access blocked: " + e);
  }
};
